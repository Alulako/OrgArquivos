// Nome: Arthur Domingues Rios, Número USP: 13731751
// Nome: Ana Luíza Lasta Kodama, Número USP: 14651204

#ifndef _REGISTROCABECALHO_H
#define _REGISTROCABECALHO_H

    #include <stdbool.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>

    typedef struct registro_cabecalho cabecalho;

    void escrever_cabecalho(FILE *filein, FILE *fileout);

#endif
