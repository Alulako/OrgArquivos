// Nome: Arthur Domingues Rios, Número USP: 13731751
// Nome: Ana Luíza Lasta Kodama, Número USP: 14651204

#ifndef _ARVOREBCABECALHO_H
#define _ARVOREBCABECALHO_H

    #include <stdio.h>
    #include <stdlib.h>

    typedef struct arvoreb_cabecalho arvbcabecalho;

    void escrever_cabecalhoarvb(FILE *fileout);

#endif
